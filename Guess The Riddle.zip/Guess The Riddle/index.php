<?php 
include_once ('riddle.php');
$result = mysqli_query($conn,"SELECT * FROM rid order by RAND() limit 1");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link href="index.css" rel="stylesheet" />
    <script src="script.js" defer></script>
    <script>src="tick.js"</script>
    <title>Document</title>
</head>
<body>
    <?php
        $i=0;
        while($row = mysqli_fetch_array($result)) { 
    ?>
   <h1 class="heading1">Guess The Riddle</h1>
   <p class="inst">Drop the right answer in the drop field in the middle.</p>
    <h1 class="heading2"><?php echo $row["riddle_name"]; ?></h1>
   
    <div class="rid">
        <p><?php echo $row["riddle"]; ?></p>        
    </div>
    
    <div class="container" style="margin-left: 1250px; margin-right: 75px;  margin-top: -295px;">
        <p class="draggable" draggable="true"><?php echo $row["ans_1"]; ?></p>
        <p class="draggable" draggable="true"><?php echo $row["ans_2"]; ?></p>
        <p class="draggable" draggable="true"><?php echo $row["ans_3"]; ?></p>
    </div>
   
    <div class="container" style="margin-left: 650px;margin-right: 550px;margin-top: -250px ; margib-bottom:0px;background: #ffffff00; border: 5px solid purple;" id="given_ans"></div>

    <p style="display:none;" id="correct_ans"><?php echo $row["c_ans"]; ?></p> 
    
    <button onclick="cond()" class="button1"><i class="fa fa-check fa-4x" aria-hidden="true"></i></button>
    <a href="index.php">
    <button type="button" class="button2"><i class="fa fa-refresh fa-4x" aria-hidden="true"></i></button>
    </a>
    

    
   <?php
        $i++;
         }
    ?>
</body>
</html>