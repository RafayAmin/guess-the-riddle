function cond() {
    var a = Document.getElemenntbyID("given_ans").value;
    var b = Document.getElemenntbyID("correct_ans").value;
if (a==b) {

    document.write("Correct")
    
} else {
    document.write("Wrong")
}
}